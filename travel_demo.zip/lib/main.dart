import 'package:flutter/material.dart';
import 'package:readmore/readmore.dart';
// import 'package:travel_demo/widget/image_list_item.dart';
import 'package:travel_demo/widget/image_list_view.dart';
import 'package:travel_demo/widget/info_item.dart';
import 'package:travel_demo/widget/top_icons.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SafeArea(
        child: Scaffold(
          body: SingleChildScrollView(
            child: Column(
              children: [
                Stack(
                  clipBehavior: Clip.none,
                  children: [
                    BackgroundImage(),
                    topIcons(),
                    ImageInfo(),
                    ImageListView(),
                  ],
                ),
                Column(
                  children: [
                    InfoItem(),
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 30.0),
                      child: Description(),
                    ),
                    SizedBox(
                      height: 20,
                    ),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 30.0, vertical: 20),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          PriceColumn(),
                          CircleButton(),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class BackgroundImage extends StatelessWidget {
  const BackgroundImage({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 350,
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          bottomLeft: Radius.circular(80),
          bottomRight: Radius.circular(80),
        ),
        child: Image.asset(
          'images/1.jpg',
          fit: BoxFit.cover,
        ),
      ),
    );
  }
}

class ImageInfo extends StatelessWidget {
  const ImageInfo({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 30,
      left: 40,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'La Selva',
            style: TextStyle(fontSize: 30, color: Colors.white),
          ),
          Row(
            children: [
              Icon(Icons.location_on, color: Colors.white),
              Text(
                'Peru,South America',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
            ],
          )
        ],
      ),
    );
  }
}

class Description extends StatelessWidget {
  const Description({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          'Description',
          style: TextStyle(fontSize: 20),
        ),
        SizedBox(
          height: 10,
        ),
        Text(
          'Flutter is Google’s mobile UI open source framework to build high-quality native (super fast) interfaces for iOS and Android ',
        ),
      ],
    );
  }
}

class PriceColumn extends StatelessWidget {
  const PriceColumn({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.start,
      children: [
        Text(
          'Total Price',
          style: TextStyle(fontSize: 22),
        ),
        Text(
          '\$1270',
          style: TextStyle(fontSize: 35, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }
}

class CircleButton extends StatelessWidget {
  const CircleButton({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RawMaterialButton(
      constraints: BoxConstraints(
        minWidth: 75,
        minHeight: 75,
      ),
      fillColor: Colors.black,
      shape: CircleBorder(),
      onPressed: () {},
      child: Icon(
        Icons.chevron_right_outlined,
        size: 50,
        color: Colors.white,
      ),
    );
  }
}
