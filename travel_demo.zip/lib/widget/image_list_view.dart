import 'package:flutter/material.dart';

import 'image_list_item.dart';

class ImageListView extends StatelessWidget {
  const ImageListView({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 10,
      top: 80,
      child: Container(
        height: 450,
        width: 100,
        child: ListView.builder(
          itemCount: 4,
          itemBuilder: (ctx, i) {
            return Container(
              margin: EdgeInsets.only(bottom: 5),
              child: imageListItem(),
            );
          },
        ),
      ),
    );
  }
}
