import 'package:flutter/material.dart';

class imageListItem extends StatelessWidget {
  const imageListItem({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        print('akz');
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white, width: 3),
          borderRadius: BorderRadius.circular(20),
        ),
        height: 75,
        width: 75,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Image.asset(
            'images/1.jpg',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}
