import 'package:flutter/material.dart';

class InfoItem extends StatelessWidget {
  const InfoItem({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 80,
        left: 15,
        right: 15,
        bottom: 15,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          Container(
            decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.black.withOpacity(.2),
                ),
                borderRadius: BorderRadius.circular(30)),
            height: 100,
            width: 100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  'Distance',
                  style: TextStyle(
                    fontSize: 17,
                  ),
                ),
                Text(
                  '7Km',
                  style: TextStyle(
                      fontSize: 22,
                      color: Color(0xff78CADE),
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.black.withOpacity(.2),
                ),
                borderRadius: BorderRadius.circular(30)),
            height: 100,
            width: 100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  'Temp',
                  style: TextStyle(
                    fontSize: 17,
                  ),
                ),
                Text(
                  '28 \u2103',
                  style: TextStyle(
                      fontSize: 22,
                      color: Color(0xff78CADE),
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Container(
            decoration: BoxDecoration(
                border: Border.all(
                  color: Colors.black.withOpacity(.2),
                ),
                borderRadius: BorderRadius.circular(30)),
            height: 100,
            width: 100,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  'Rating',
                  style: TextStyle(
                    fontSize: 17,
                  ),
                ),
                Text(
                  '4.8',
                  style: TextStyle(
                      fontSize: 22,
                      color: Color(0xff78CADE),
                      fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
