class Slider {
  String? id;
  String? imagePath;
  String? name;
  String? place;
  String? description;
  String? distance;
  String? temp;
  String? rating;
  String? totalprice;
  Slider({
    this.id,
    this.imagePath,
    this.name,
    this.place,
    this.description,
    this.temp,
    this.distance,
    this.rating,
    this.totalprice,
  });
}
